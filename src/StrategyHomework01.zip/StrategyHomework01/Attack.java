package StrategyHomework01;

import StrategyHomework.Monster;

public interface Attack {
    public abstract Integer attack(Monster target);
}
