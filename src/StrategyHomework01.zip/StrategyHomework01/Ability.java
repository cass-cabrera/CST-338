package StrategyHomework01;

public interface Ability {
}
